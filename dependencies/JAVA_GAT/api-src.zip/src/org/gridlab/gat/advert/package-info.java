/**
 * This package contains classes and interfaces which are used for the GAT
 * advertisement service.
 * This is an information service that can store GAT objects permanently.
 */

package org.gridlab.gat.advert;
